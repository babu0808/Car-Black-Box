/*------------------------------------------------------------------------------------------------- 
 *   Author         : Babu Malagaveli 
 *   Date           : 25 Oct 2023 16:00:04 IST
 *   File           : main.c
 *   Title          : Car Black Box
 *   Description    : Black Box implementation in an Automotive System to log critical events. 
 *                    This will help in pro-active vehicle monitoring and maintenance.
 *-----------------------------------------------------------------------------------------------*/
#include "main.h"

/* Global variables */
unsigned short timer_count = 0; // Timer count value
unsigned short sec = BLOCK_TIME_IN_SEC; // Password restriction block time
unsigned short delay = 0; // Non-blocking delay value
unsigned short write_addr; // EEPROM write address
unsigned short read_addr; // EEPROM read address

unsigned char try_flag = ON; // Flag to avoid multiple iterations
unsigned char attempts = MAX_ATTEMPTS; // Number of password tries
unsigned char passcode_bit = 0; // Index of the strings
unsigned char clock_reg[3]; // HH:MM:SS BCD values
unsigned char time_reg[9]; // String to store time values
unsigned char org_passwd[PASSWORD_LENGTH + 1]; // Actual password string
unsigned char user_passwd[PASSWORD_LENGTH + 1]; // User entry string
unsigned char check_user_passwd[PASSWORD_LENGTH + 1]; // Password re-entry string
unsigned char key_up = ON; // Flag to know if it is an up key or down key
unsigned char re_entry = OFF; // Flag to know when to re-enter a string
unsigned char clock_hand = SEC_ADDR; // Sec, min, and hr address
unsigned char disp_num = 0; // Display number for reading & downloading operation
unsigned char scroll = OFF; // Flag to know scroll of EEPROM address
unsigned char speed; // Vehicle speed value
unsigned char first_index = 0; // First index value of an event
unsigned char last_index = 0; // Last index value of an event
unsigned char back_to_menu = OFF; // Flag to know when to go back to the menu
unsigned char eeprom_log_reg[8]; // Array to store bytes read from EEPROM
unsigned char long_press = OFF; // Flag to determine long press of a key
unsigned char entry_not_full = ON; // Flag to know if passcode entry is completed
unsigned char time_not_set = ON; // Flag to know if the time value is set or not



unsigned char flag = 1; // Flag to switch between LINE1 and LINE2 of the CLCD
unsigned char ch; // Variable to store the input character
unsigned char i = 0; // Index to track the position in the CLCD line
unsigned char line_1[17]; // Array to store characters on LINE-1 of the CLCD
unsigned char line_2[17] = "                "; // Array to store characters on LINE-2 of the CLCD

const unsigned char* menu[6] = {
    (const unsigned char*) "VIEW LOG",
    (const unsigned char*) "SET TIME",
    (const unsigned char*) "CHANGE PASSWD",
    (const unsigned char*) "CLEAR LOG",
    (const unsigned char*) "DOWNLOAD LOG",
    (const unsigned char*) " "
};

DISPLAY_MODE display = DASHBOARD_SCREEN; // Stores display type
DISPLAY_MODE arrow = 0; // To hold a particular display type
EVENTS event = ON; // Stores event type
EVENTS gear = GN; // Holds a gear event type

// Initialize all peripherals & respective values

void init_config(void) {
    init_clcd();
    init_digital_keypad();
    init_timer();
    init_i2c(100000);
    init_ds1307();
    init_uart(9600);
    get_initial_values_from_eeprom();
    get_time();
    speed = (unsigned char) read_adc() / 10;
    init_adc();
    // Store ON event into EEPROM
    write_onto_eeprom(ON);
    GIE = 1;
}

// Function to check values entered from the matrix keypad

static void read_keypad_input(void) {
    unsigned char key = read_digital_keypad(STATE); // Edge-triggered switch value
    // Delay to handle bouncing effect
    for (unsigned short delay = 4000; delay--;);
    unsigned char key_level = read_digital_keypad(LEVEL); // Level-triggered switch value

    if (key == SW1) // Collision
    {
        // Store event in EEPROM while updating event value to display
        write_onto_eeprom(event = CO);
        clear_screen();
    } else if (key == SW2) // Move Gear Up
    {
        if (++gear > G4) // G4 is the top gear, cannot increase the gear further
            gear = G4;
        else
            // Store event in EEPROM while updating event value to display
            write_onto_eeprom(event = gear);
        clear_screen();
    } else if (key == SW3) // Move Gear Down
    {
        if (--gear < GR) // GR is the lowest gear, cannot decrease the gear further
            gear = GR;
        else
            write_onto_eeprom(event = gear);
        clear_screen();
    } else if (key == SW4) {
        if (display == DASHBOARD_SCREEN) {
            display = PASSWORD_SCREEN; // Change to the password screen
            clear_screen();
            ;
        } else if ((display == PASSWORD_SCREEN || display == CHG_PASSWD_SCREEN) && passcode_bit < PASSWORD_LENGTH) {
            timer_count = 0; // Bring timer count back to 0
            if (re_entry) {
                check_user_passwd[passcode_bit] = '1'; // Encode '1' into check_user_passwd string if re_entry flag is ON
            } else {
                user_passwd[passcode_bit] = '1'; // Encode '1' into user_passwd string
            }
            clcd_putch('*', LINE2(6 + passcode_bit++));
        } else if (display == VIEW_LOG_SCREEN) {
            if (disp_num != first_index && disp_num-- == 0) // Cannot scroll up beyond the first index
                disp_num = UART_LOG_ENTRIES_COUNT - 1;
            // Read event log from EEPROM
            read_from_eeprom();
            clear_screen();
            ;
        } else if (display == MENU_SCREEN) {
            key_up = OFF; // Up key is pressed
            if (arrow-- == 0) // Cannot move up beyond the very first menu item
                arrow = 0;
            clear_screen();
        } else if (display == DISP_SET_TIME && time_not_set == ON) {
            if (clock_hand++ == HOUR_ADDR)
                clock_hand = SEC_ADDR;
        }
    } else if (key == SW4) {
        if ((display == PASSWORD_SCREEN || display == CHG_PASSWD_SCREEN) && passcode_bit < PASSWORD_LENGTH) {
            timer_count = 0; // Bring timer count back to 0
            if (re_entry) {
                check_user_passwd[passcode_bit] = '0'; // Encode '0' into check_user_passwd string if re_entry flag is ON
            } else {
                user_passwd[passcode_bit] = '0'; // Encode '0' into user_passwd string
            }
            clcd_putch('*', LINE2(6 + passcode_bit++));
        } else if (display == VIEW_LOG_SCREEN) {
            if (disp_num != last_index)
                disp_num = (disp_num + 1) % UART_LOG_ENTRIES_COUNT;
            // Read event log from EEPROM
            read_from_eeprom();
            clear_screen();
            ;
        } else if (display == MENU_SCREEN) {
            key_up = ON; // Down key is pressed
            if (arrow++ == 4) // Cannot scroll down beyond the last menu item
                arrow = 4;
            clear_screen();
        } else if (display == DISP_SET_TIME) {
            set_time(); // Set time function
        }
    } else if (display == MENU_SCREEN && key_level == SW5) {
        long_press = TMR2ON = ON; // Turn ON long_press flag & timer
        if (timer_count >= CHANGE_DIS_ON_LONG_PRESS * 10) {
            TMR2ON = OFF; // Turn OFF the timer & reset the timer count
            timer_count = 0;
            clear_screen();
            display = arrow + VIEW_LOG_SCREEN; // Change to appropriate display
            if (display == VIEW_LOG_SCREEN) {
                disp_num = first_index; // Keep disp_num at the first index in view log option
            } else if (display == DISP_SET_TIME) {
                time_not_set = ON; // Allow the changes to be made in clock_reg values
                clock_hand = HOUR_ADDR; // Clock hand at Hour field
            } else if (display == CLEAR_LOG) {
                write_onto_eeprom(CL); // Store Clear log event if it is clear log option
            } else if (display == DOWNLOAD_LOG) {
                download_log();
                write_onto_eeprom(DL); // Write event onto EEPROM
            }
        }
    } else if ((display == MENU_SCREEN || display == VIEW_LOG_SCREEN || display == DISP_SET_TIME) && key_level == SW5) {
        long_press = TMR2ON = ON; // Turn ON long_press flag & timer
        if (timer_count >= CHANGE_DIS_ON_LONG_PRESS * 10) {
            if (display == VIEW_LOG_SCREEN) {
                display = MENU_SCREEN;
            } else if (display == MENU_SCREEN) {
                display = DASHBOARD_SCREEN;
            } else if (display == DISP_SET_TIME) {
                time_not_set = OFF; // Restrict the changes in clock_reg values
                delay = 0; // Reset delay value used for blinking
                write_onto_eeprom(ST); // Store event in EEPROM
                switch (clock_hand) {
                    case SEC_ADDR: // Reduce sec field
                    case MIN_ADDR: // Reduce min field
                        if (clock_reg[HOUR_ADDR - clock_hand]-- == 0)
                            clock_reg[HOUR_ADDR - clock_hand] = 0x59;
                        break;
                    case HOUR_ADDR: // Reduce hr field
                        if (clock_reg[HOUR_ADDR - clock_hand]-- == 0)
                            clock_reg[HOUR_ADDR - clock_hand] = 0x23;
                }
                write_ds1307(clock_hand, clock_reg[HOUR_ADDR - clock_hand]);
                back_to_menu = ON; // New time is set, so turn ON back_to_menu flag
            }
            TMR2ON = OFF;
            timer_count = 0;
            clear_screen();
        }
    } else if (long_press) {
        long_press = TMR2ON = OFF, timer_count = 0; // With some long press, timer activates & timer_count changes, so must be reset
    }

    if ((display == PASSWORD_SCREEN || display == CHG_PASSWD_SCREEN) && passcode_bit == PASSWORD_LENGTH && entry_not_full) {
        if (re_entry) {
            check_user_passwd[PASSWORD_LENGTH] = '\0'; // Once index reaches PASSWORD_LENGTH, clear LCD display and put a terminating '\0'
        } else {
            user_passwd[PASSWORD_LENGTH] = '\0';
        }
        TMR2ON = entry_not_full = OFF; // Turn OFF the timer, reset timer count & note the entry full
        timer_count = 0;
        clear_screen();
        ;
    } else if (display == PASSWORD_SCREEN && timer_count >= PASSWORD_IDLE_TIME * 10) {
        display = DASHBOARD_SCREEN; // Change back to Dashboard screen after inactivity time
        TMR2ON = OFF; // Turn OFF the timer, reset timer count & passcode_bit index
        timer_count = passcode_bit = 0;
        clear_screen();
    } else if (display == CHG_PASSWD_SCREEN && timer_count >= CHG_PASSWD_TO_MENU_IN_SEC * 10) {
        display = MENU_SCREEN; // Change back to Menu screen after inactivity time
        DISP_ON_AND_CURSOR_OFF;
        TMR2ON = OFF; // Turn OFF the timer, reset timer count & passcode_bit index
        timer_count = passcode_bit = 0;
        clear_screen();
    }
}

void main(void) {
    // Initialize system configurations
    init_config();

    while (1) {
        // Continuously read the current time
        get_time();

        // Read and store the speed as an unsigned character
        speed = (unsigned char) read_adc();

        switch (display) {
            case DASHBOARD_SCREEN:
                // Display dashboard information
                clcd_print("  TIME    EVENT  SPEED", LINE1(0));
                display_time();
                display_event(event);
                itoa_display(speed);
                break;

            case PASSWORD_SCREEN:
            case CHG_PASSWD_SCREEN:
                if (passcode_bit < PASSWORD_LENGTH) {
                    // Turn ON the timer and set the entry flag to ON
                    TMR2ON = entry_not_full = ON;

                    if (!passcode_bit) {
                        // Display password entry message based on re-entry
                        const char* entryMessage = (re_entry) ? "RE-ENTER PASSWORD" : "ENTER PASSWORD";
                        clcd_print(entryMessage, LINE1(1));
                    }
                } else {
                    // Turn off the display and cursor
                    DISP_ON_AND_CURSOR_OFF;

                    if (display == PASSWORD_SCREEN) {
                        // Handle password verification
                        if (!my_strcmp((const unsigned char*) org_passwd, (const char*) user_passwd)) {
                            // Password matches, display a success message and switch to the menu
                            clcd_print("PASSWORD SUCCESS", LINE1(0));

                            if (delay++ == 300) {
                                // Switch to the menu screen, reset variables, and clear the display
                                display = MENU_SCREEN;
                                delay = arrow = passcode_bit = 0;
                                attempts = MAX_ATTEMPTS;
                                clear_screen();
                            }
                        } else {
                            // Password does not match
                            if (try_flag) {
                                --attempts;
                                try_flag = OFF;
                            }
                            clcd_print("WRONG PASSWD", LINE1(0));

                            if (attempts) {
                                clear_screen();
                                clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                                clcd_print("Wrong password", LINE1(0));
                                clcd_putch(attempts + '0', LINE2(0));
                                clcd_print("Attempts left", LINE2(1));
                                // Display the remaining chances for password entry
                                if (delay++ == 300) {
                                    try_flag = ON;
                                    delay = timer_count = passcode_bit = 0;
                                    clear_screen();
                                }
                            } else {
                                TMR2ON = ON;
                                //lock he user for 15 minutes
                                sec = 60;
                                clear_screen();
                                clcd_print("You are locked ", LINE1(0));
                                clcd_print("Wait for...60 sec", LINE2(0));
                                while (sec) {
                                    clcd_putch(sec / 10 + '0', LINE1(11));
                                    clcd_putch((sec % 10 + '0'), LINE2(12));
                                }
                                if (timer_count >= 10) {
                                    clear_screen();
                                    if (--sec == 0) {
                                        TMR2ON = OFF;
                                        try_flag = ON;
                                        passcode_bit = 0;
                                        attempts = MAX_ATTEMPTS;
                                        sec = BLOCK_TIME_IN_SEC;
                                    }

                                    timer_count = 0;
                                }
                            }
                        }
                    } else if (display == CHG_PASSWD_SCREEN) {
                        // Handle password change
                        if (re_entry) {
                            if (!my_strcmp(check_user_passwd, user_passwd)) {
                                clcd_print("PASSWD CHANGED", LINE1(0));

                                if (delay++ == 300) {
                                    delay = passcode_bit = 0;
                                    re_entry = OFF;
                                    display = MENU_SCREEN;
                                    write_onto_eeprom(CH);

                                    for (unsigned char i = 0; i < PASSWORD_LENGTH; i++) {
                                        org_passwd[i] = user_passwd[i];
                                        write_ext_eeprom(i, user_passwd[i]);
                                    }

                                    clear_screen();
                                }
                            } else {
                                clcd_print("   Try again    ", LINE2(0));

                                if (delay++ == 300) {
                                    delay = passcode_bit = 0;
                                    re_entry = OFF;
                                    clear_screen();
                                }
                            }
                        } else {
                            passcode_bit = 0;
                            re_entry = ON;
                            clear_screen();
                        }
                    }
                }
                break;

            case MENU_SCREEN:
                // Display the menu
                display_menu(menu);
                break;

            case VIEW_LOG_SCREEN:
                // Display the event log
                display_view_log();
                break;

            case DISP_SET_TIME:
                if (back_to_menu) {
                    // Inform about time change and return to the menu
                    clcd_print("TIME CHANGED", LINE1(0));
                    clcd_print("BACK TO MENU", LINE2(0));

                    if (delay++ == 300) {
                        display = MENU_SCREEN;
                        delay = 0;
                        back_to_menu = OFF;
                        clear_screen();
                    }
                } else {
                    // Display the current time entry format
                    clcd_print("HH:MM:SS", LINE1(4));
                    display_time();
                }
                break;

            case CLEAR_LOG:
                // Display log clearing message
                clcd_print("LOG CLEARED", LINE1(2));
                clcd_print("BACK TO MENU", LINE2(0));

                if (delay++ == 300) {
                    display = MENU_SCREEN;
                    delay = 0;
                    clear_screen();
                }
                break;

            case DOWNLOAD_LOG:
                // Display log download completion message
                clcd_print("LOG DOWNLOADED", LINE1(0));
                clcd_print("BACK TO MENU ", LINE2(0));

                if (delay++ == 300) {
                    display = MENU_SCREEN;
                    delay = 0;
                    clear_screen();
                }
                display_uart(); //when the user chose to view the logs, it should display on the cutecom using uart
                break;
        }

        // Continuously check for user input
        read_keypad_input();
    }
}
