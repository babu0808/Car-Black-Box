/*------------------------------------------------------------------------------------------------- 
 *   Author         : Babu Malagaveli
 *   Date           : Thu 23.10.2023 16:00:04 IST
 *   File           : ds1307.c
 *   Title          : ds1307 Driver
 *   Description    : Module to configure RTC DS1307
 *-----------------------------------------------------------------------------------------------*/

#include <xc.h>
#include "main.h"

void init_ds1307(void) {
    unsigned char dummy;

    dummy = read_ds1307(SEC_ADDR);
    dummy = dummy & 0x7F;
    write_ds1307(SEC_ADDR, dummy); // ch = 0
}

unsigned char read_ds1307(unsigned char addr) {
    unsigned char data;
    /*inserted by me*/
    i2c_wait_for_idle(); //check if the bus us busy -> waits till the bus gets idle
    i2c_write(SLAVE_WRITE); //transmit uponn unique address of RTC + intention
    i2c_write(addr); //transmit the address from where the data has to be read

    /*inserted by me*/
    //    i2c_start();
    //    i2c_stop();
    i2c_rep_start(); //intention is changed
    i2c_write(SLAVE_READ); //intention is read
    data = i2c_read(0); //read from the buffer register
    i2c_stop();

    return data;
}

void write_ds1307(unsigned char addr, unsigned char data) // SEc_ADDR, data
{
    /*inserted by me*/
    //    i2c_wait_for_idle(void); //check if the bus us busy -> waits till the bus gets idle(); //check if the bus us busy -> waits till the bus gets idel

    i2c_start();
    i2c_write(SLAVE_WRITE);
    i2c_write(addr);
    i2c_write(data);
    i2c_stop();
}
