/*------------------------------------------------------------------------------------------------- 			    
 *   Author         : Babu Malagaveli
 *   Date           : 25 Oct 2023 16:00:04 IST
 *   File           : uart.h
 *   Title          : Universal Asynchronus Receive Transmit
 *   Description    : A simple program to demonstrate host and target communication
 *   		      using UART
 *-----------------------------------------------------------------------------------------------*/
#ifndef UART_H
#define	UART_H

#define FOSC                20000000

void init_uart(unsigned long baud);
unsigned char getchar(void);
void putchar(unsigned char data);
void puts(const char *s);
#endif	/* UART_H */