#include "main.h"

/**
 * Writes event data onto the internal EEPROM.
 *
 * This function writes event data to the EEPROM, including the event type,
 * time information, and other related data. It also handles scroll of the
 * event log entries when the maximum count is reached.
 *
 */
void write_onto_eeprom(EVENTS store_event) {
    unsigned char write_offset = (unsigned char) PASSWORD_LENGTH + 4;
    unsigned char scroll_addr = (unsigned char) 8 * UART_LOG_ENTRIES_COUNT + write_offset;

    if (store_event == CL) {
        write_addr = write_offset;
        scroll = OFF;
    }

    // Write 6 bytes from time string (HH, MM & SS)
    for (unsigned char i = 0; i < 8; i++) {
        if (i != 2 && i != 5) // Skip ':' part
            write_ext_eeprom(write_addr++, time_reg[i]); // Address post-incremented
    }

    // Write 1 byte event value
    write_ext_eeprom(write_addr++, store_event); // Address post-incremented

    // Write 1 byte speed value
    write_ext_eeprom(write_addr++, speed); // Address post-incremented

    // Check for scroll of index since only UART_LOG_ENTRIES_COUNT event entries are allowed
    if (write_addr == scroll_addr) {
        write_addr = write_offset;
    }

    // Note that the first and last index should be in the range from 0 to UART_LOG_ENTRIES_COUNT - 1
    if (scroll) { // If scroll occurred, the last index takes value of the first index, and the first index points to a new entry
        last_index = first_index;
        first_index = (write_addr == write_offset) ? 0 : (unsigned char) ((write_addr - write_offset) / 8);
    } else { // Otherwise, the first index remains at 0, and the last index points to a new entry
        first_index = 0;
        last_index = (write_addr == write_offset) ? (unsigned char) (UART_LOG_ENTRIES_COUNT - 1) : (unsigned char) ((write_addr - 2 * write_offset) / 8);

        if (write_addr == write_offset)
            scroll = ON;
    }

    // Store the initial storing address of the next event onto the EEPROM address after the password
    write_ext_eeprom((unsigned char) PASSWORD_LENGTH, (unsigned char) write_addr);

    // Store the scroll flag value onto the next EEPROM address
    write_ext_eeprom((unsigned char) PASSWORD_LENGTH + 1, (unsigned char) scroll);

    // Store the first and last flag values onto the next consecutive EEPROM addresses
    write_ext_eeprom((unsigned char) PASSWORD_LENGTH + 2, (unsigned char) first_index);
    write_ext_eeprom((unsigned char) PASSWORD_LENGTH + 3, (unsigned char) last_index);
}
