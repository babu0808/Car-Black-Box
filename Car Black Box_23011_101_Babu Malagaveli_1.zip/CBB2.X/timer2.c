
/*
 * Filename : timer2.c
 Name       : Babu Malagaveli
Date        : 25.10.2023
Description : To implement the Timer.
 */
#include <xc.h> // include processor files - each processor file is guarded.  
#include "main.h"

void init_timer(void) {

    TMR2ON = 1;
    PR2 = 250;
    TMR2IF = 0;
}

//used timer2 as we can turn off the timers when we do not need
