#include "main.h"

/**
 * Reads 8 bytes from the internal EEPROM.
 * The function calculates the base address to start reading from EEPROM, 
 * reads 6 bytes for the clock value, 1 byte for the event value, 
 * and 1 byte for the speed value, and stores them in the eeprom_log_reg array.
 */
void read_from_eeprom(void) {
    read_addr = disp_num * 8 + PASSWORD_LENGTH + 4;
    eeprom_log_reg[0] = (unsigned char)(read_ext_eeprom(read_addr) & 0xFF);
    eeprom_log_reg[1] = (unsigned char)(read_ext_eeprom(read_addr + 1) & 0xFF);
    eeprom_log_reg[2] = (unsigned char)(read_ext_eeprom(read_addr + 2) & 0xFF);
    eeprom_log_reg[3] = (unsigned char)(read_ext_eeprom(read_addr + 3) & 0xFF);
    eeprom_log_reg[4] = (unsigned char)(read_ext_eeprom(read_addr + 4) & 0xFF);
    eeprom_log_reg[5] = (unsigned char)(read_ext_eeprom(read_addr + 5) & 0xFF);
    eeprom_log_reg[6] = (unsigned char)(read_ext_eeprom(read_addr + 6) & 0xFF);
    eeprom_log_reg[7] = (unsigned char)(read_ext_eeprom(read_addr + 7) & 0xFF);
}

/**
 * Reads initial values from the EEPROM.
 * This function retrieves the original password, EEPROM write address, 
 * scroll flag, first flag, and last flag from EEPROM storage.
 */
void get_initial_values_from_eeprom(void) {
    // Get the original password from EEPROM storage (0x00)
    for (unsigned char i = 0; i < PASSWORD_LENGTH; i++) {
        org_passwd[i] = (read_ext_eeprom(i) - '0') ? '1' : '0';
    }
    org_passwd[PASSWORD_LENGTH] = '\0';

    // Get the EEPROM write address from the next address
    write_addr = read_ext_eeprom((unsigned char) PASSWORD_LENGTH);

    // Get the scroll flag value from the next address
    scroll = read_ext_eeprom((unsigned char) PASSWORD_LENGTH + 1);

    // Get the value of the first and last_index flag from next consecutive addresses
    first_index = read_ext_eeprom((unsigned char) PASSWORD_LENGTH + 2);
    last_index = read_ext_eeprom((unsigned char) PASSWORD_LENGTH + 3);
}
