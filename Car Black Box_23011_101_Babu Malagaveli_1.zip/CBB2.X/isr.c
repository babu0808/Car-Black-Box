#include "main.h"

//Extern timer count value
extern unsigned short timer_count;

void __interrupt() isr(void) {
    //Check if timer0 interrupt flag is set
    if (TMR2IF) {
        TMR0 = TMR0 + 8;
        //Increment timer count
        timer_count++;
        //Clear the interrupt flag
        TMR2IF = 0;
    }
}


